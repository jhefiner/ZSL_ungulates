library(ggplot2)
library(readr)
library(tidyverse)
library(dplyr)
library(ratdat)
library(scales)
library(agridat)

install.packages("readr")

setwd("data_raw")

banco_de_dados <- read.csv("sempc/data_raw/dt.csv")
view(banco_de_dados)

banco_de_dados <- banco_de_dados %>%
  mutate(publication = as.factor(paste(author, year)))
summary(banco_de_dados$publication)

banco_de_dados <- banco_de_dados %>%
  mutate(publication = as.factor(paste(author, year)))%>%
  filter(!is.na(new_analitical_method)) %>%
  filter(!is.na(new_detection_method)) %>%
  filter(!is.na(new_environment)) %>%
  filter(!is.na(method)) %>%
  filter(!is.na(D)) %>%
  select(publication, family, species, genus, D, Log10.D, SE, new_detection_method, new_analitical_method, method, bodymass_g_pantheria, new_environment, Lat, Long, Altitude, annual_precipitation, sampling_effort, country)
view(banco_de_dados)

with(banco_de_dados, tapply(D, list(new_detection_method, new_analitical_method), length))
table(banco_de_dados$method)

banco_de_dados$method <- as.factor(banco_de_dados$method)
banco_de_dados$new_environment <- as.factor(banco_de_dados$new_environment)
banco_de_dados$new_analitical_method <- as.factor(banco_de_dados$Lat)
banco_de_dados$new_detection_method <- as.factor(banco_de_dados$Altitude)
banco_de_dados$new_analitical_method <- as.factor(banco_de_dados$annual_precipitation)
banco_de_dados$logmass_kg <- log(banco_de_dados$bodymass_g_pantheria/1000)
banco_de_dados$sqrt_rainfall <- sqrt(banco_de_dados$annual_precipitation)

t <- lm(log(D) ~ method + family +
          logmass_kg + new_environment +
          log(abs(Lat)) + log(Altitude) + 
          sqrt_rainfall + I(sqrt_rainfall^2), 
        data = banco_de_dados)
summary(t)

t1 <- lm(log(D) ~ method + family +
          logmass_kg + new_environment +
          log(abs(Lat)) + log(Altitude) + 
          sqrt_rainfall + I(sqrt_rainfall^2), 
        data = banco_de_dados)
summary(t1)
plot(t)


AIC(t,t1)




# Graficos

d_methods<-ggplot(banco_de_dados, aes(x = method, y = log(D))) +
  geom_boxplot(fill = "lightgrey", color = "black") +  # boxplot
  labs(x = "Method", y = "Densidade") +  # rótulos dos eixos
  theme_minimal() +  # tema minimalista
  theme(axis.text.x = element_text(angle = 45, hjust = 1))  # ângulo das legendas do eixo X

d_environments <- ggplot(banco_de_dados, aes(x = new_environment, y = log(D))) +
  geom_boxplot(fill = "lightgrey", color = "black") +  # boxplot
  labs(x = "Ambientes", y = "Densidade") +  # rótulos dos eixos
  theme_minimal() +  # tema minimalista
  theme(axis.text.x = element_text(angle = 45, hjust = 1))  # ângulo das legendas do eixo X

d_family <- ggplot(banco_de_dados, aes(x = family, y = log(D))) +
  geom_boxplot(fill = "lightgrey", color = "black") +  # boxplot
  labs(x = "Familia", y = "Densidade") +  # rótulos dos eixos
  theme_minimal() +  # tema minimalista
  theme(axis.text.x = element_text(angle = 45, hjust = 1))  # ângulo das legendas do eixo X


# Calcular as contagens de cada espécie
cnt_species <- banco_de_dados %>%
  group_by(species) %>%
  summarise(Quantidade = n()) %>%
  arrange(desc(Quantidade))  # Ordenar em ordem decrescente

# Criar o gráfico de barras usando os dados contados
qt_species <- ggplot(cnt_species, aes(x = reorder(species, -Quantidade), y = Quantidade)) +
  geom_bar(stat = "identity", fill = "lightgrey", color = "black") +  # gráfico de barras com contagem
  labs(x = "Species", y = "Number of Estimates") +  # rótulos dos eixos
  theme_minimal() +  # tema minimalista
  theme(axis.text.x = element_text(angle = 45, hjust = 1))  # ângulo das legendas do eixo X

cnt_genus <- banco_de_dados %>%
  group_by(genus) %>%
  summarise(Quantidade = n()) %>%
  arrange(desc(Quantidade))  # Ordenar em ordem decrescente

# Criar o gráfico de barras usando os dados contados
qt_genus <- ggplot(cnt_genus, aes(x = reorder(genus, -Quantidade), y = Quantidade)) +
  geom_bar(stat = "identity", fill = "lightgrey", color = "black") +  # gráfico de barras com contagem
  labs(x = "Genus", y = "Number of Estimates") +  # rótulos dos eixos
  theme_minimal() +  # tema minimalista
  theme(axis.text.x = element_text(angle = 45, hjust = 1))  # ângulo das legendas do eixo X

# Calcular as contagens de cada familia
cnt_family <- banco_de_dados %>%
  group_by(family) %>%
  summarise(Quantidade = n()) %>%
  arrange(desc(Quantidade))  # Ordenar em ordem decrescente

# Criar o gráfico de barras usando os dados contados
qt_family <- ggplot(cnt_family, aes(x = reorder(family, -Quantidade), y = Quantidade)) +
  geom_bar(stat = "identity", fill = "lightgrey", color = "black") +  # gráfico de barras com contagem
  labs(x = "Families", y = "Number of Estimates") +  # rótulos dos eixos
  theme_minimal() +  # tema minimalista
  theme(axis.text.x = element_text(angle = 45, hjust = 1))  # ângulo das legendas do eixo X

hist_logd <- ggplot(banco_de_dados, aes(x = Log10.D)) +
  geom_histogram(fill = "lightgrey", color = "black") +  # boxplot
  labs(x = "Density values converted to base 10 logarithms", y = "Quantity") +  # rótulos dos eixos
  theme_minimal() +  # tema minimalista
  theme(axis.text.x = element_text(angle = 45, hjust = 1))  # ângulo das legendas do eixo X


cnt_ndm <- banco_de_dados %>%
  group_by(new_detection_method) %>%
  summarise(Quantidade = n())

cnt_ndm <- cnt_ndm %>%
  mutate(porcentagem = (Quantidade/301) * 100)

rm(grafico_pizza)


ggsave("sempc/images/d_methods.png", plot = d_methods, width = 6, height = 4, dpi = 300)

ggsave("sempc/images/d_environments.png", plot = d_environments, width = 6, height = 4, dpi = 300)

ggsave("sempc/images/d_family.png", plot = d_family, width = 6, height = 4, dpi = 300)

ggsave("sempc/images/qt_species.png", plot = qt_species, width = 6, height = 4, dpi = 300)

ggsave("sempc/images/qt_family.png", plot = qt_family, width = 6, height = 4, dpi = 300)

ggsave("sempc/images/qt_genus.png", plot = qt_genus, width = 6, height = 4, dpi = 300)

ggsave("sempc/images/hist_logd.png", plot = hist_logd, width = 6, height = 4, dpi = 300)





